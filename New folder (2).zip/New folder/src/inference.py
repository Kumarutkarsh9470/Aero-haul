import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

# Configuration
MODEL_PATH = os.path.join('models', 'plant_cnn.h5')
IMG_DIR = os.path.join('data', 'test', 'test')  # test images
OUTPUT_DIR = 'outputs'
IMG_SIZE = (224, 224)


def generate_overlay(model, img_path, output_path, alpha=0.4):
    import cv2
    import numpy as np
    import os
    from src.utils import IMG_SIZE, CLASS_NAMES

    # Load & preprocess
    orig = cv2.imread(img_path)

    if orig is None:
        print(f" Failed to load image: {img_path}")
        return  # Skip this image

    img = cv2.resize(orig, IMG_SIZE)
    img_norm = img / 255.0
    inp = np.expand_dims(img_norm, axis=0)

    # Predict
    preds = model.predict(inp, verbose=0)
    class_id = np.argmax(preds)
    label = CLASS_NAMES[class_id]

    # Overlay text
    annotated = orig.copy()
    cv2.putText(annotated, label, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

    # Save
    os.makedirs(output_path, exist_ok=True)
    filename = os.path.basename(img_path)
    out_path = os.path.join(output_path, filename)
    cv2.imwrite(out_path, annotated)
    print(f" Saved annotated image to: {out_path}")


def main():
    # Load model
    model = tf.keras.models.load_model(MODEL_PATH)
    # Process each demo image
    for fname in os.listdir(IMG_DIR):
        img_path = os.path.join(IMG_DIR, fname)
        generate_overlay(model, img_path, OUTPUT_DIR)


if __name__ == '__main__':
    main()