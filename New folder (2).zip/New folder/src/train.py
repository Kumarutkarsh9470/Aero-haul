import os
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from src.utils import get_data_generators, build_cnn_model

# Configuration
IMG_SIZE = (224, 224)
BATCH_SIZE = 32
EPOCHS = 15
DATA_DIR = os.path.join('data')
MODEL_PATH = os.path.join('models', 'plant_cnn.h5')


def plot_history(history, output_path):
    plt.figure()
    plt.plot(history.history['accuracy'], label='train_acc')
    plt.plot(history.history['val_accuracy'], label='val_acc')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.savefig(output_path)


def main():
    os.makedirs('models', exist_ok=True)

    # Data generators
    train_gen, valid_gen = get_data_generators(
        data_dir=DATA_DIR,
        img_size=IMG_SIZE,
        batch_size=BATCH_SIZE
    )

    # Build model
    model = build_cnn_model(input_shape=IMG_SIZE + (3,), num_classes=train_gen.num_classes)
    model.compile(
        optimizer='adam',
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    model.summary()

    # Callbacks
    checkpoint = ModelCheckpoint(
        MODEL_PATH, monitor='val_accuracy', save_best_only=True, verbose=1
    )
    earlystop = EarlyStopping(
        monitor='val_accuracy', patience=3, restore_best_weights=True, verbose=1
    )

    # Train
    history = model.fit(
        train_gen,
        validation_data=valid_gen,
        epochs=EPOCHS,
        steps_per_epoch=train_gen.samples // BATCH_SIZE,
        validation_steps=valid_gen.samples // BATCH_SIZE,
        callbacks=[checkpoint, earlystop]
    )

    # Plot
    plot_history(history, os.path.join('models', 'training_curve.png'))
    print(f"Model and training curve saved to {os.path.abspath('models')}")


if __name__ == '__main__':
    main()