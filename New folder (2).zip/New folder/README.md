# AI‑Driven Crop Health Detection

## Project Structure

your-project/
├── data/ # Sample/demo input images
├── models/ # Saved model files and plots
├── src/ # Python code (train, inference, utils)
├── notebooks/ # Jupyter notebooks for exploration & training
├── requirements.txt # Python dependencies
└── README.md

## Installation

```bash
python -m venv venv
# Activate the virtual environment:
# macOS / Linux:
source venv/bin/activate
# Windows PowerShell:
venv\Scripts\Activate.ps1
# Windows Command Prompt:
venv\Scripts\activate.bat

pip install --upgrade pip
pip install -r requirements.txt
```
